<p align="center">
<a href="https://mypointapp.gr" target="_blank">
<img src="https://sphereweb.mypointapp.gr/images/logo/mypoint-logo.png" alt="myPoint logo"></a></p>

<p align="center">
<a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## About My Point App

 My Point App created by Sphere Web Solutions for small Business Corporations.
- AADE MyData connected
- Invoice Provider.
- Outcomes
- Tasks.
- Retail Receipts Printing.
- Services.

Laravel is accessible online from any browser.

## License

The MyPoint App is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
