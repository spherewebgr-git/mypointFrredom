<div class="col s12 m6">
    <div class="card">
        <div class="card-content taxheaven-calendar">
            <h5 class="card-title mb-3">Φορολογικές Υποχρεώσεις - <?php echo e(\Carbon\Carbon::now()->locale('el_GR')->timezone('Europe/Athens')->getTranslatedMonthName('M')); ?> <?php echo e(date('Y')); ?></h5>

            <div class="taxheaven-calendar--inner">
                <?php $__currentLoopData = $feed->channel->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="taxheaven-calendar-item">
                        <div class="col s2">
                            <div class="date"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($item->pubDate))->format('d/m')); ?></div>
                            <div class="year"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($item->pubDate))->format('Y')); ?></div>
                        </div>
                        <div class="col s10">
                            <a href="<?php echo e($item->link); ?>" target="_blank"><?php echo e($item->title); ?></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
</div>

<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/pages/parts/card-rss.blade.php ENDPATH**/ ?>