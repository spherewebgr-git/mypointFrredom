<div id="permissions">
    <div class="card-panel">
        <div class="row">
            <form action="<?php echo e(route('settings.permissions')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <h4 style="font-size: 16px;font-weight: 400;margin: 45px 0 10px 25px;">Χρήστες</h4>
                <div class="divider"></div>
                <div class="col s12 input-field">

                </div>
                <h4 style="font-size: 16px;font-weight: 400;margin: 45px 0 10px 25px;">Δικαιώματα ανά Ρόλο Χρήστη</h4>
                <div class="divider"></div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/settings/permissions.blade.php ENDPATH**/ ?>