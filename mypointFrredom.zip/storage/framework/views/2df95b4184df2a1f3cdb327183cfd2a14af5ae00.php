<?php $__env->startSection('title','Ρυθμίσεις Εφαρμογής'); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/select2/select2-materialize.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/page-account-settings.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="tabs-vertical mt-1 section">
        <div class="row">
            <div class="col l3 s12">
                <!-- tabs  -->
                <div class="card-panel">
                    <ul class="tabs">
                        <li class="tab">
                            <a href="#general">
                                <i class="material-icons">person</i>
                                <span>ΔΙΑΧΕΙΡΙΣΤΗΣ</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#permissions">
                                <i class="material-icons">person</i>
                                <span>ΧΡΗΣΤΕΣ & ΔΙΚΑΙΩΜΑΤΑ</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#info">
                                <i class="material-icons">error_outline</i>
                                <span> ΦΟΡΟΛΟΓΙΚΑ </span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#addresses">
                                <i class="material-icons">business</i>
                                <span> ΔΙΕΥΘΥΝΣΕΙΣ </span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#mydata">
                                <i class="material-icons">link</i>
                                <span> ΣΥΝΔΕΣΗ myData </span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#invoices">
                                <i class="material-icons">settings</i>
                                <span>ΡΥΘΜΙΣΕΙΣ ΠΑΡΑΣΤΑΤΙΚΩΝ</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#parastatika">
                                <i class="material-icons">library_books</i>
                                <span>ΕΙΔΗ ΠΑΡΑΣΤΑΤΙΚΩΝ</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#seires">
                                <i class="material-icons">import_export</i>
                                <span>ΣΕΙΡΕΣ ΠΑΡΑΣΤΑΤΙΚΩΝ</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#products">
                                <i class="material-icons">local_grocery_store</i>
                                <span>ΡΥΘΜΙΣΕΙΣ ΠΡΟΪΟΝΤΩΝ</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col l9 s12">
                <!-- tabs content -->
                <?php echo $__env->make('settings.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.permissions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.mydata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.addresses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.invoices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.seires', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.parastatika', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('settings.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/scripts/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/form_repeater/jquery.repeater.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/app-invoice.js')); ?>"></script>
    <script>
        $m = jQuery.noConflict();
        $m(document).ready(function(){
           $m('#openMydataInfo').on('click', function(){
              $m('.mydata-howto').removeClass('hide');
           });
           $m('#show_products').on('change', function(){
               if($m(this).is(':checked')) {
                   //$m('.product-settings').removeClass('hide');
                   $m('.product-settings').slideDown();
               } else {
                   //$m('.product-settings').addClass('hide');
                   $m('.product-settings').slideUp();
               }
           });
           $m('input[type="checkbox"]').on('click', function(){
               let dataName = $m(this).attr('name');
              if(!$m(this).is(':checked')){
                  $m('<input type="hidden" name="'+dataName+'" value="off" />').insertAfter(this);
              }
           });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/settings/index.blade.php ENDPATH**/ ?>