<?php if(isset($invoice->sale_invoiceID)): ?>
    <?php $__env->startSection('title','Επεξεργασία Τιμολογίου Πώλησης'); ?>
<?php else: ?>
    <?php $__env->startSection('title','Νέο Τιμολόγιο Πώλησης'); ?>
<?php endif; ?>

<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="invoice-edit-wrapper section">
        <div class="row">
            <!-- invoice view page -->
            <form class="form invoice-item-repeater"
                  <?php if(isset($invoice->sale_invoiceID)): ?> action="<?php echo e(route('sale_invoice.update', ['invoice' => $invoice->hashID])); ?>"
                  <?php else: ?> action="<?php echo e(route('sale_invoice.store')); ?>" <?php endif; ?> method="post">
                <?php echo csrf_field(); ?>
                <div class="col xl9 m8 s12">
                    <div class="card">
                        <div class="card-content px-36">
                            <div class="progress" style="display: none">
                                <div class="indeterminate"></div>
                            </div>
                            <!-- header section -->
                            <div class="row mb-3">
                                <div class="col xl4 m12 display-flex align-items-center">
                                    <h6 class="invoice-number mr-4 mb-5">Σειρά: </h6>
                                    <select name="seira" id="seira">
                                        <?php $__currentLoopData = $seires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seira): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($seira->letter); ?>" <?php if(isset($invoice->seira) && $invoice->seira == $seira->letter): ?> selected <?php endif; ?>><?php echo e($seira->letter); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <h6 class="invoice-number mr-4 mb-5 ml-4">Τ.Π.# </h6>
                                    <input type="text" name="invoiceID" placeholder="000" id="invoiceID"
                                           <?php if(isset($invoice)): ?>
                                           value="<?php echo e(old('sale_invoiceID', $invoice->sale_invoiceID)); ?>"
                                           disabled <?php elseif($last != ''): ?> value="<?php echo e($last + 1); ?>" <?php endif; ?>>
                                </div>
                                <div class="col xl8 m12">
                                    <div class="invoice-date-picker display-flex align-items-center">
                                        <div class="display-flex align-items-center">
                                            <small>Ημ/νία Έκδοσης: </small>
                                            <div class="display-flex ml-4">
                                                <input type="text" class="datepicker mb-1" name="date"
                                                       placeholder="Επιλέξτε Ημ/νία"
                                                       <?php if(isset($invoice->date)): ?>
                                                       value="<?php echo e(\Carbon\Carbon::parse($invoice->date)->format('d/m/Y')); ?>"
                                                       <?php else: ?>
                                                       value="<?php echo e(date('d/m/Y')); ?>

                                                       <?php endif; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- invoice address and contact -->
                            <div class="row mb-3">
                                <div class="col l6 s12">
                                    <h6>Χρέωση σε</h6>
                                    <div class="col s12  input-field">
                                        <div class="col s3 m4">
                                            <label class="m-0" for="client">Πελάτης</label>
                                        </div>
                                        <select class="invoice-item-select browser-default" id="client" name="client">
                                            <option value="" selected disabled>Επιλέξτε Πελάτη</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($client->disabled != 1): ?>
                                                    <option <?php if(isset($invoice)): ?>
                                                            <?php if($invoice->client_id == $client->id): ?>
                                                            selected
                                                            <?php endif; ?>
                                                            <?php endif; ?> value="<?php echo e($client->id); ?>"><?php echo e($client->company); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col l6 s12">
                                    <h6>Τρόπος πληρωμής</h6>
                                    <div class="col s12  input-field">
                                        <div class="col s12 m12">
                                            <label class="m-0" for="paymentMethod">Επιλέξτε τρόπο πληρωμής</label>
                                        </div>
                                        <select name="paymentMethod" id="paymentMethod">
                                            <option value="1" <?php if(isset($invoice->payment_method) && $invoice->payment_method == 1): ?> selected <?php endif; ?>>Επαγ. Λογαριασμός Πληρωμών Ημεδαπής</option>
                                            <option value="2" <?php if(isset($invoice->payment_method) && $invoice->payment_method == 2): ?> selected <?php endif; ?>>Επαγ. Λογαριασμός Πληρωμών Αλλοδαπής</option>
                                            <option value="3" <?php if(isset($invoice->payment_method) && $invoice->payment_method == 3): ?> selected <?php endif; ?>>Μετρητά</option>
                                            <option value="4" <?php if(isset($invoice->payment_method) && $invoice->payment_method == 4): ?> selected <?php endif; ?>>Επιταγή</option>
                                            <option value="5" <?php if(!isset($invoice->payment_method) || $invoice->payment_method == 5): ?> selected <?php endif; ?>>Επί Πιστώσει</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <!-- product details table-->
                            <div class="invoice-product-details mb-3">
                                <div data-repeater-list="services">
                                    <?php if(isset($invoice->sale_invoiceID) && count($invoice->deliveredGoods) > 0): ?>
                                        <?php $__currentLoopData = $invoice->deliveredGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-2 count-repeater" data-repeater-item="">
                                                <!-- invoice Titles -->
                                                <div class="row mb-1">
                                                    <div class="col s2">
                                                        <h6 class="m-0">Ποσότητα</h6>
                                                    </div>
                                                    <div class="col s3 m8">
                                                        <h6 class="m-0">Περιγραφή</h6>
                                                    </div>
                                                    <div class="col s2">
                                                        <h6 style="margin-left: -40px">Τιμή</h6>
                                                    </div>

                                                </div>
                                                <div class="invoice-item display-flex">
                                                    <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                        <div class="col m2 s12 input-field">
                                                            <input type="hidden" name="id" value="<?php echo e($good->id); ?>">
                                                            <input type="text" value="<?php echo e($good->quantity); ?>"
                                                                   name="quantity"
                                                                   class="quantity-field">
                                                        </div>
                                                        <div class="col m8 s12 input-field">
                                                        <textarea class="materialize-textarea"
                                                                  name="description"><?php echo e(getProduct($good->delivered_good_id)['product_name']); ?></textarea>
                                                        </div>

                                                        <div class="col m2 s12 input-field">
                                                            <input type="text" placeholder="000" name="price"
                                                                   class="price-field" value="<?php echo e($good->product_price); ?>">
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="mb-2 count-repeater" data-repeater-item="">
                                            <!-- invoice Titles -->
                                            <div class="row mb-1">
                                                <div class="col s2">
                                                    <h6 class="m-0">Ποσότητα</h6>
                                                </div>
                                                <div class="col s3 m8">
                                                    <h6 class="m-0">Περιγραφή</h6>
                                                </div>
                                                <div class="col s2">
                                                    <h6 style="margin-left: -40px">Τιμή</h6>
                                                </div>

                                            </div>
                                            <div class="invoice-item display-flex">
                                                <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                    <div class="col m2 s12 input-field">
                                                        <input type="text" value="1" name="quantity"
                                                               class="quantity-field">
                                                    </div>
                                                    <div class="col m8 s12 input-field">
                                                        <textarea class="materialize-textarea"
                                                                  name="description"></textarea>
                                                    </div>

                                                    <div class="col m2 s12 input-field">
                                                        <input type="text" placeholder="000" name="price"
                                                               class="price-field">
                                                    </div>
                                                </div>
                                                <div
                                                    class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                                <div class="input-field">
                                    <button class="btn invoice-repeat-btn" data-repeater-create="" type="button">
                                        <i class="material-icons left">add</i>
                                        <span>Προσθήκη Γραμμής</span>
                                    </button>
                                </div>

                            </div>
                            <!-- invoice subtotal -->
                            <div class="invoice-subtotal">
                                <div class="row">
                                    <div class="col m5 s12">

                                    </div>
                                    <div class="col xl4 m7 s12 offset-xl3">
                                        <ul>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Υποσύνολο</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="subtotal">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Φ.Π.Α. (24%)</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span id="fpa">00.00</span>
                                                </h6>
                                            </li>
                                            <li>
                                                <div class="divider mt-2 mb-2"></div>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Συνολικό Ποσό</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="finalPrice">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Πληρωτέο</span>
                                                <h6 class="invoice-subtotal-value" style="font-weight: bold">&euro;
                                                    <span id="toPay">00.00</span></h6>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- invoice action  -->
                <div class="col xl3 m4 s12">
                    <div class="card invoice-action-wrapper mb-10">
                        <div class="card-content">
                            <?php if(!isset($invoice->mark)): ?>
                                <div class="invoice-action-btn">
                                    <div class="invoice-action-btn">
                                        <a href="<?php echo e(route('sale_invoice.mydata', $invoice->hashID)); ?>" class="btn-block btn btn-light-indigo waves-effect waves-light">
                                            <i class="material-icons mr-4">backup</i>
                                            <span>Αποστολή στο myData</span>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="invoice-action-btn">
                                <?php if(isset($invoice->sale_invoiceID)): ?>
                                    <input type="submit" value="Ενημέρωση Τιμολογίου" style="color: #fff;width: 100%;"
                                           class="btn display-flex align-items-center justify-content-center">
                                <?php else: ?>
                                    <input type="submit" value="Καταχώρηση Τιμολογίου" style="color: #fff;width: 100%;"
                                           class="btn display-flex align-items-center justify-content-center">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-terms display-flex flex-column" style="margin-top: 8rem;">
                        <div class="display-flex justify-content-between pb-2">
                            <span>Να σταλεί και στον πελάτη</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="sendClient">
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                        <div class="display-flex justify-content-between pb-2">
                            <span>Πληρωμένο</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="paid"
                                           <?php if(isset($invoice->paid) && $invoice->paid == 1): ?> checked <?php endif; ?>>
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="ajax-preloader">
            <div class="preloader-wrapper big active">
                <div class="spinner-layer spinner-blue-only">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('vendors/form_repeater/jquery.repeater.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/scripts/app-invoice.js')); ?>"></script>
    <script>
        $m = jQuery.noConflict();
        $m(document).ready(function () {
            $m(this).countPrices();
            <?php if(Session::has('notify')): ?>
            M.toast({
                html: '<?php echo e(Session::get("notify")); ?>',
                classes: 'rounded',
                timeout: 10000
            });
            <?php endif; ?>

            $m('select#seira').on('change', function () {
                $m('.ajax-preloader').addClass('active');

                let invoiceLetter = $m('select#seira option:selected').text();

                let pageToken = $m('meta[name="csrf-token"]').attr('content');

                $m.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': pageToken
                    }
                });

                $m.ajax({
                    url: "<?php echo e(url('/last-invoice-ajax')); ?>",
                    method: 'post',
                    data: {
                        seira: invoiceLetter
                    },
                    success: function (result) {
                        console.log(result);
                        $m('.ajax-preloader').removeClass('active');
                        $m('input#invoiceID').val(result);
                    }
                });
            });

        });
        $m('input[type="submit"]').on('click', function () {
            $m('.progress').show();
        })
        $m.fn.countPrices = function () {
            let finalPrice = 0;
            $m('.count-repeater').each(function () {
                let quantity = $m(this).find('.quantity-field').val();
                let price = $m(this).find('.price-field').val();
                finalPrice += quantity * price;
            });
            $m('#subtotal').text(parseFloat(finalPrice).toFixed(2));
            $m('#fpa').text(parseFloat((24 / 100) * finalPrice).toFixed(2));
            $m('#finalPrice').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
            if (finalPrice > 300 && $m('input#hasParakratisi').is(':checked')) {
                $m('#parakratisi').text(parseFloat((20 / 100) * finalPrice).toFixed(2));
                $m('#toPay').text(parseFloat((24 / 100) * finalPrice + finalPrice - (20 / 100) * finalPrice).toFixed(2));
                $m('#parakratisiTotal').show();
            } else {
                $m('#parakratisi').text(parseFloat(0).toFixed(2));
                $m('#toPay').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
                $m('#parakratisiTotal').hide();
            }
        }

        $m(document).on('mouseout', '.count-repeater', function () {
            $m(this).countPrices();
        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/sale_invoices/new.blade.php ENDPATH**/ ?>