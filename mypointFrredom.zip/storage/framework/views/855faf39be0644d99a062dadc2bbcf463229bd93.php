<?php $__env->startSection('title','Νέα Απόδειξη Λιανικής'); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="invoice-edit-wrapper section">
        <div class="row">
            <form class="form invoice-item-repeater" <?php if(isset($retail->retailID)): ?> action="<?php echo e(route('retail-receipts.update', $retail->hashID)); ?>" <?php else: ?> action="<?php echo e(route('retail-receipts.store')); ?>" <?php endif; ?> method="post">
                <?php echo csrf_field(); ?>
                <div class="col xl9 m8 s12">
                    <div class="card">
                        <div class="card-content px-36">
                            <div class="progress" style="display: none">
                                <div class="indeterminate"></div>
                            </div>
                            <!-- header section -->
                            <div class="row mb-3">
                                <div class="col xl4 m12 display-flex align-items-center">
                                    <h6 class="invoice-number mr-4 mb-5">Σειρά: </h6>
                                    <select name="seira" id="seira">
                                        <?php $__currentLoopData = $seires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seira): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($seira->letter); ?>"
                                                    <?php if(isset($retail->seira) && $retail->seira == $seira->letter): ?> selected <?php endif; ?>><?php echo e($seira->letter); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <h6 class="invoice-number mr-4 mb-5 ml-4">ΦΤΜ Ζ # </h6>
                                    <input type="text" name="invoiceID" placeholder="000" id="invoiceID"
                                           <?php if(isset($retail)): ?>
                                               value="<?php echo e(old('retailID', $retail->retailID)); ?>"
                                           disabled <?php elseif(isset($last) && $last != ''): ?> value="<?php echo e($last + 1); ?>" <?php endif; ?>>
                                </div>
                                <div class="col xl8 m12">
                                    <div class="invoice-date-picker display-flex align-items-center">
                                        <div class="display-flex align-items-center">
                                            <small>Ημ/νία Έκδοσης: </small>
                                            <div class="display-flex ml-4">
                                                <input type="text" class="datepicker mb-1" name="date"
                                                       placeholder="Επιλέξτε Ημ/νία"
                                                       <?php if(isset($retail->date)): ?>
                                                           value="<?php echo e(\Carbon\Carbon::parse($retail->date)->format('d/m/Y')); ?>"
                                                       <?php else: ?>
                                                           value="<?php echo e(date('d/m/Y')); ?>

                                                       <?php endif; ?>"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- product details table-->
                            <div class="invoice-product-details mb-3">
                                <div data-repeater-list="services">
                                    <?php if(isset($retail) && count($retail->items) > 0): ?>
                                        <?php $__currentLoopData = $retail->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-2 count-repeater" data-repeater-item="">
                                                <!-- invoice Titles -->
                                                <div class="row mb-1">
                                                    <div class="col s12 m5">
                                                        <h6 class="m-0">Προϊόν/Υπηρεσία</h6>
                                                    </div>
                                                    <div class="col s12 m2">
                                                        <h6 class="m-0">Συντελεστής ΦΠΑ</h6>
                                                    </div>
                                                    <div class="col s12 m3">
                                                        <h6 class="m-0">Τρόπος Πληρωμής</h6>
                                                    </div>
                                                    <div class="col s12 m1">
                                                        <h6 style="margin-left: -40px">Τιμή</h6>
                                                    </div>
                                                    <div class="col s12 m1">
                                                        <h6 style="margin-left: -40px">ΦΠΑ</h6>
                                                    </div>
                                                </div>
                                                <div class="invoice-item display-flex">
                                                    <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                        <div class="col m5 s12 input-field">
                                                            <input type="text" value="<?php echo e($service->product_service); ?>" name="product_service"
                                                                   class="product-field">
                                                        </div>
                                                        <div class="col m2 s12 input-field">
                                                            <select name="vat_id" id="vat_id" class="invoice-item-select browser-default">
                                                                <option value="1" <?php if($service->vat_id == 1): ?> selected <?php endif; ?>>24%</option>
                                                                <option value="4" <?php if($service->vat_id == 4): ?> selected <?php endif; ?>>17%</option>
                                                                <option value="2" <?php if($service->vat_id == 2): ?> selected <?php endif; ?>>13%</option>
                                                                <option value="5" <?php if($service->vat_id == 5): ?> selected <?php endif; ?>>9%</option>
                                                                <option value="3" <?php if($service->vat_id == 3): ?> selected <?php endif; ?>>6%</option>
                                                                <option value="6" <?php if($service->vat_id == 6): ?> selected <?php endif; ?>>4%</option>
                                                                <option value="7" <?php if($service->vat_id == 7): ?> selected <?php endif; ?>>0%</option>
                                                                <option value="8" <?php if($service->vat_id == 8): ?> selected <?php endif; ?>>Μισθοδοσία, Αποσβέσεις κλπ.</option>
                                                            </select>
                                                        </div>

                                                        <div class="col m3 s12 input-field">
                                                            <select name="payment_method" id="payment_method" class="invoice-item-select browser-default">
                                                                <option value="1" <?php if($service->payment_method == 1): ?> selected <?php endif; ?>>Επαγ. Λογαριασμός Πληρωμών Ημεδαπής</option>
                                                                <option value="2" <?php if($service->payment_method == 2): ?> selected <?php endif; ?>>Επαγ. Λογαριασμός Πληρωμών Αλλοδαπής</option>
                                                                <option value="3" <?php if($service->payment_method == 3): ?> selected <?php endif; ?>>Μετρητά</option>
                                                                <option value="4" <?php if($service->payment_method == 4): ?> selected <?php endif; ?>>Επιταγή</option>
                                                                <option value="5" <?php if($service->payment_method == 5): ?> selected <?php endif; ?>>Επί Πιστώσει</option>
                                                                <option value="6" <?php if($service->payment_method == 6): ?> selected <?php endif; ?>>Web Banking</option>
                                                                <option value="7" <?php if($service->payment_method == 7): ?> selected <?php endif; ?>>POS / e-POS</option>
                                                            </select>
                                                        </div>
                                                        <div class="col m1 s12 input-field">
                                                            <input type="text" value="<?php echo e($service->price); ?>" name="price" placeholder="0.00"
                                                                   class="price-field">
                                                        </div>
                                                        <div class="col m1 s12 input-field">
                                                            <input type="text" value="<?php echo e($service->vat); ?>" name="vat" placeholder="0.00"
                                                                   class="vat-field">
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="item" value="<?php echo e($service->id); ?>">
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="mb-2 count-repeater" data-repeater-item="">
                                            <!-- invoice Titles -->
                                            <div class="row mb-1">
                                                <div class="col s12 m5">
                                                    <h6 class="m-0">Προϊόν/Υπηρεσία</h6>
                                                </div>
                                                <div class="col s12 m2">
                                                    <h6 class="m-0">Συντελεστής ΦΠΑ</h6>
                                                </div>
                                                <div class="col s12 m3">
                                                    <h6 class="m-0">Τρόπος Πληρωμής</h6>
                                                </div>
                                                <div class="col s12 m1">
                                                    <h6 style="margin-left: -40px">Τιμή</h6>
                                                </div>
                                                <div class="col s12 m1">
                                                    <h6 style="margin-left: -40px">ΦΠΑ</h6>
                                                </div>
                                            </div>
                                            <div class="invoice-item display-flex">
                                                <div class="invoice-item-filed row pt-1" style="width: 100%">
                                                    <div class="col m5 s12 input-field">
                                                        <input type="text" value="ΕΜΠΟΡΕΥΜΑΤΑ" name="product_service"
                                                               class="product-field">
                                                    </div>
                                                    <div class="col m2 s12 input-field">
                                                        <select name="vat_id" id="vat_id" class="invoice-item-select browser-default">
                                                            <option value="1">24%</option>
                                                            <option value="4">17%</option>
                                                            <option value="2">13%</option>
                                                            <option value="5">9%</option>
                                                            <option value="3">6%</option>
                                                            <option value="6">4%</option>
                                                            <option value="7">0%</option>
                                                            <option value="8">Μισθοδοσία, Αποσβέσεις κλπ.</option>
                                                        </select>
                                                    </div>

                                                    <div class="col m3 s12 input-field">
                                                        <select name="payment_method" id="payment_method" class="invoice-item-select browser-default">
                                                            <option value="1">Επαγ. Λογαριασμός Πληρωμών Ημεδαπής</option>
                                                            <option value="2">Επαγ. Λογαριασμός Πληρωμών Αλλοδαπής</option>
                                                            <option value="3" selected>Μετρητά</option>
                                                            <option value="4">Επιταγή</option>
                                                            <option value="5">Επί Πιστώσει</option>
                                                            <option value="6">Web Banking</option>
                                                            <option value="7">POS / e-POS</option>
                                                        </select>
                                                    </div>
                                                    <div class="col m1 s12 input-field">
                                                        <input type="text" value="" name="price" placeholder="0.00"
                                                               class="price-field">
                                                    </div>
                                                    <div class="col m1 s12 input-field">
                                                        <input type="text" value="" name="vat" placeholder="0.00"
                                                               class="vat-field">
                                                    </div>
                                                </div>
                                                <div
                                                    class="invoice-icon display-flex flex-column justify-content-between">
                                                  <span data-repeater-delete="" class="delete-row-btn">
                                                    <i class="material-icons">clear</i>
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                                <div class="input-field">
                                    <button class="btn invoice-repeat-btn" data-repeater-create="" type="button">
                                        <i class="material-icons left">add</i>
                                        <span>Προσθήκη Υπηρεσίας</span>
                                    </button>
                                </div>

                            </div>
                            <!-- invoice subtotal -->
                            <div class="invoice-subtotal">
                                <div class="row">
                                    <div class="col m5 s12">

                                    </div>
                                    <div class="col xl4 m7 s12 offset-xl3">
                                        <ul>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Υποσύνολο</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="subtotal">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Φ.Π.Α. (24%)</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span id="fpa">00.00</span>
                                                </h6>
                                            </li>
                                            <li>
                                                <div class="divider mt-2 mb-2"></div>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Συνολικό Ποσό</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="finalPrice">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between" id="parakratisiTotal">
                                                <span class="invoice-subtotal-title">Παρακράτηση</span>
                                                <h6 class="invoice-subtotal-value">&euro; <span
                                                        id="parakratisi">00.00</span></h6>
                                            </li>
                                            <li class="display-flex justify-content-between">
                                                <span class="invoice-subtotal-title">Πληρωτέο</span>
                                                <h6 class="invoice-subtotal-value" style="font-weight: bold">&euro;
                                                    <span id="toPay">00.00</span></h6>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sidebar -->
                <div class="col xl3 m4 s12">
                    <div class="card invoice-action-wrapper mb-10">
                        <div class="card-content">
                            <div class="invoice-action-btn">
                                <?php if(isset($retail) && !isset($retail->mark)): ?>

                                        <a href="<?php echo e(route('retail-receipts.mydata', $retail->hashID)); ?>" class="btn-block btn btn-light-indigo waves-effect waves-light">
                                            <i class="material-icons mr-4">backup</i>
                                            <span>Αποστολή στο myData</span>
                                        </a>

                                <?php endif; ?>
                                <?php if(isset($retail->retailID)): ?>
                                    <input type="submit" value="Ενημέρωση Απόδειξης Λιανικής" style="color: #fff;width: 100%;"
                                           class="btn display-flex align-items-center justify-content-center">
                                <?php else: ?>
                                    <input type="submit" value="Έκδοση Απόδειξης Λιανικής" style="color: #fff;width: 100%;"
                                           class="btn display-flex align-items-center justify-content-center">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-terms display-flex flex-column" style="margin-top: 8rem;">
                        <div class="display-flex justify-content-between pb-2">
                            <span>Εκτύπωση μετά την έκδοση</span>
                            <div class="switch">
                                <label>
                                    <input type="checkbox" name="printNow" checked>
                                    <span class="lever"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="ajax-preloader">
            <div class="preloader-wrapper big active">
                <div class="spinner-layer spinner-blue-only">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                        <div class="circle"></div>
                    </div><div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('vendors/form_repeater/jquery.repeater.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/scripts/app-invoice.js')); ?>"></script>
    <script>
        $r = jQuery.noConflict();
        $r(document).ready(function() {
            $r('select#seira').on('change', function () {
                $r('.ajax-preloader').addClass('active');

                let retailLetter = $r('select#seira option:selected').text();

                let pageToken = $r('meta[name="csrf-token"]').attr('content');

                $r.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': pageToken
                    }
                });

                $r.ajax({
                    url: "<?php echo e(url('/last-retail-ajax')); ?>",
                    method: 'post',
                    data: {
                        seira: retailLetter
                    },
                    success: function (result) {
                        $r('.ajax-preloader').removeClass('active');
                        $r('input#retailID').val(result);
                    }
                });
            });
        });

        $r('input[type="submit"]').on('click', function () {
            $r('.progress').show();
        })
        $r.fn.countPrices = function () {
            let finalPrice = 0;
            $r('.count-repeater').each(function () {
                let price = parseInt($r(this).find('.price-field').val());
                if(price) {
                    if($r(this).find('.vat-field').val() === '') {
                        $r(this).find('.vat-field').val(parseFloat((24/100) * price).toFixed(2));
                    }
                    finalPrice += price;
                }
            });

            $r('#subtotal').text(parseFloat(finalPrice).toFixed(2));
            $r('#fpa').text(parseFloat((24 / 100) * finalPrice).toFixed(2));
            $r('#finalPrice').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
            $r('#toPay').text(parseFloat((24 / 100) * finalPrice + finalPrice).toFixed(2));
            $r('#parakratisiTotal').hide();
        }

        $r(document).on('mouseout', '.count-repeater', function () {
            $r(this).countPrices();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/retail_receipts/new.blade.php ENDPATH**/ ?>