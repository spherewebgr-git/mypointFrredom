<!-- BEGIN: Footer-->
<footer
  class="<?php echo e($configData['mainFooterClass']); ?> <?php if($configData['isFooterFixed']=== true): ?><?php echo e('footer-fixed'); ?><?php else: ?> <?php echo e('footer-static'); ?> <?php endif; ?> <?php if($configData['isFooterDark']=== true): ?> <?php echo e('footer-dark'); ?> <?php elseif($configData['isFooterDark']=== false): ?> <?php echo e('footer-light'); ?> <?php else: ?> <?php echo e($configData['mainFooterColor']); ?> <?php endif; ?>">
  <div class="footer-copyright">
    <div class="container">
      <span>&copy; myPoint App 2022  All rights reserved.
      </span>
      <span class="right hide-on-small-only">
        Developed by <a href="https://www.sphereweb.gr"
                        target="_blank">Sphere Web Solutions</a>
      </span>
    </div>
  </div>
</footer>

<!-- END: Footer-->
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/panels/footer.blade.php ENDPATH**/ ?>