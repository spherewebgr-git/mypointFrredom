<div id="info">
    <div class="card-panel">
        <form action="<?php echo e(route('settings.update', ['form' => 'info'])); ?>" class="infovalidate" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col s12 m6">
                    <div class="input-field">
                        <input id="company" type="text" name="company" <?php if(isset($settings['company'])): ?> value="<?php echo e($settings['company']); ?>" <?php endif; ?>>
                        <label for="company">Επωνυμία Επιχείρησης</label>
                    </div>
                </div>
                <div class="col s12 m6">
                    <div class="input-field">
                        <input id="company_title" name="title" type="text" <?php if(isset($settings['title'])): ?> value="<?php echo e($settings['title']); ?>" <?php endif; ?>>
                        <label for="company_title">Διακριτικός Τίτλος</label>
                    </div>
                </div>
                <div class="col s12">
                    <div class="input-field">
                        <input id="business" name="business" type="text" <?php if(isset($settings['business'])): ?> value="<?php echo e($settings['business']); ?>" <?php endif; ?>>
                        <label for="business">Επάγγελμα</label>
                    </div>
                </div>
                <div class="col s6">
                    <div class="input-field">
                        <input id="vat" name="vat" type="text" <?php if(isset($settings['vat'])): ?>  value="<?php echo e($settings['vat']); ?>" <?php endif; ?>>
                        <label for="vat">Α.Φ.Μ.</label>
                    </div>
                </div>
                <div class="col s6">
                    <label for="doy">ΔΟΥ</label>
                    <div class="input-field" style="margin-top: -7px;">
                        <select class="browser-default" id="doy" name="doy">
                            <option value="" disabled selected>Επιλέξτε ΔΟΥ</option>
                            <option value="Α ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Α ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ Α' ΑΘΗΝΩΝ</option>
                            <option value="Δ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Δ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ Δ' ΑΘΗΝΩΝ</option>
                            <option value="ΣΤ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΣΤ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΣΤ' ΑΘΗΝΩΝ</option>
                            <option value="ΙΒ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΙΒ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΙΒ' ΑΘΗΝΩΝ, Ζωγράφου</option>
                            <option value="ΙΓ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΙΓ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΙΓ' ΑΘΗΝΩΝ</option>
                            <option value="ΙΔ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΙΔ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΙΔ' ΑΘΗΝΩΝ</option>
                            <option value="ΙΖ ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΙΖ ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΙΖ' ΑΘΗΝΩΝ</option>
                            <option value="ΚΑΤΟΙΚΩΝ ΕΞΩΤΕΡΙΚΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΚΑΤΟΙΚΩΝ ΕΞΩΤΕΡΙΚΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΚΑΤΟΙΚΩΝ ΕΞΩΤΕΡΙΚΟΥ</option>
                            <option value="Φ.Α.Ε. ΑΘΗΝΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Φ.Α.Ε. ΑΘΗΝΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ Φ.Α.Ε. ΑΘΗΝΩΝ, Καλλιθέα</option>
                            <option value="ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΑΓΙΟΥ ΔΗΜΗΤΡΙΟΥ</option>
                            <option value="ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ'): ?> selected <?php endif; ?>>ΔΟΥ ΑΓΙΩΝ ΑΝΑΡΓΥΡΩΝ</option>
                            <option value="ΑΙΓΑΛΕΩ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΑΙΓΑΛΕΩ'): ?> selected <?php endif; ?>>ΔΟΥ ΑΙΓΑΛΕΩ</option>
                            <option value="ΑΜΑΡΟΥΣΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΑΜΑΡΟΥΣΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΑΜΑΡΟΥΣΙΟΥ</option>
                            <option value="ΒΥΡΩΝΑ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΒΥΡΩΝΑ'): ?> selected <?php endif; ?>>ΔΟΥ ΒΥΡΩΝΑ</option>
                            <option value="ΓΑΛΑΤΣΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΓΑΛΑΤΣΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΓΑΛΑΤΣΙΟΥ</option>
                            <option value="ΓΛΥΦΑΔΑΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΓΛΥΦΑΔΑΣ'): ?> selected <?php endif; ?>>ΔΟΥ ΓΛΥΦΑΔΑΣ</option>
                            <option value="ΗΛΙΟΥΠΟΛΗΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΗΛΙΟΥΠΟΛΗΣ'): ?> selected <?php endif; ?>>ΔΟΥ ΗΛΙΟΥΠΟΛΗΣ</option>
                            <option value="ΚΑΛΛΙΘΕΑΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΚΑΛΛΙΘΕΑΣ'): ?> selected <?php endif; ?>>ΔΟΥ ΚΑΛΛΙΘΕΑΣ</option>
                            <option value="ΚΗΦΙΣΙΑΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΚΗΦΙΣΙΑΣ'): ?> selected <?php endif; ?>>ΔΟΥ ΚΗΦΙΣΙΑΣ</option>
                            <option value="ΜΟΣΧΑΤΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΜΟΣΧΑΤΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΜΟΣΧΑΤΟΥ</option>
                            <option value="Ν.ΙΩΝΙΑΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Ν.ΙΩΝΙΑΣ'): ?> selected <?php endif; ?>>ΔΟΥ Ν.ΙΩΝΙΑΣ</option>
                            <option value="Ν.ΣΜΥΡΝΗΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Ν.ΣΜΥΡΝΗΣ'): ?> selected <?php endif; ?>>ΔΟΥ Ν.ΣΜΥΡΝΗΣ</option>
                            <option value="Ν.ΗΡΑΚΛΕΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Ν.ΗΡΑΚΛΕΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ Ν.ΗΡΑΚΛΕΙΟΥ</option>
                            <option value="ΝΙΚΑΙΑΣ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΝΙΚΑΙΑΣ'): ?> selected <?php endif; ?>>ΔΟΥ ΝΙΚΑΙΑΣ</option>
                            <option value="ΠΑΛ. ΦΑΛΗΡΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΠΑΛ. ΦΑΛΗΡΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΠΑΛ. ΦΑΛΗΡΟΥ</option>
                            <option value="Α ΠΕΡΙΣΤΕΡΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Α ΠΕΡΙΣΤΕΡΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ Α' ΠΕΡΙΣΤΕΡΙΟΥ</option>
                            <option value="Β ΠΕΡΙΣΤΕΡΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'Β ΠΕΡΙΣΤΕΡΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ Β' ΠΕΡΙΣΤΕΡΙΟΥ</option>
                            <option value="ΧΑΛΑΝΔΡΙΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΧΑΛΑΝΔΡΙΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΧΑΛΑΝΔΡΙΟΥ</option>
                            <option value="ΧΟΛΑΡΓΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΧΟΛΑΡΓΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΧΟΛΑΡΓΟΥ</option>
                            <option value="ΨΥΧΙΚΟΥ" <?php if(isset($settings['doy']) && $settings['doy'] == 'ΨΥΧΙΚΟΥ'): ?> selected <?php endif; ?>>ΔΟΥ ΨΥΧΙΚΟΥ</option>
                        </select>
                    </div>
                </div>

                <div class="col s12 display-flex justify-content-end form-action">
                    <button type="submit" class="btn indigo waves-effect waves-light mr-1">Αποθήκευση Αλλαγών</button>
                </div>

            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/settings/info.blade.php ENDPATH**/ ?>