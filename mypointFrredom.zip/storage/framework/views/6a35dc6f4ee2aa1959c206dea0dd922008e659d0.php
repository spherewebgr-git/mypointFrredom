<?php if(isset($client)): ?>
    <?php $__env->startSection('title','Επεξεργασία καρτέλας πελάτη'); ?>
<?php else: ?>
    <?php $__env->startSection('title','Καταχώρηση νέου πελάτη'); ?>
<?php endif; ?>

<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
        <!-- Search for small screen-->
        <div class="container">
            <div class="row">
                <div class="col s10 m6 l6">
                    <h5 class="breadcrumbs-title mt-0 mb-0">
                        <?php if(isset($client)): ?>
                            <span>Επεξεργασία καρτέλας πελάτη</span>
                        <?php else: ?>
                            <span>Καταχώρηση νέου πελάτη</span>
                        <?php endif; ?>
                    </h5>
                </div>
            </div>
        </div>
    </div>
    <div class="col s12 m12 l12">
        <div id="prefixes" class="card card card-default scrollspy">
            <div class="card-content">
                <h4 class="card-title">Στοιχεία Επιχείρησης</h4>
                <form <?php if(isset($client)): ?> action="<?php echo e(route('client.update', ['client' => $client])); ?>" <?php else: ?> action="<?php echo e(route('client.store')); ?>" <?php endif; ?> method="post" class="addresses-item-repeater">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="input-field col s12 m2">
                            <i class="material-icons prefix">settings_ethernet</i>
                            <input id="code_number" type="text" name="code_number" <?php if(isset($client->code_number)): ?> value="<?php echo e(old('code_number', $client->code_number)); ?>" <?php endif; ?> required>
                            <label for="code_number" class="">Κωδικός *</label>
                        </div>
                        <div class="input-field col s12 m3">
                            <i class="material-icons prefix">business_center</i>
                            <input id="company" type="text" name="company" <?php if(isset($client->company)): ?> value="<?php echo e(old('company', $client->company)); ?>" <?php endif; ?> required>
                            <label for="company" class="">Επωνυμία Εταιρείας *</label>
                        </div>
                        <div class="input-field col s12 m4">
                            <i class="material-icons prefix">computer</i>
                            <input id="work_title" type="text" name="work_title" <?php if(isset($client->work_title)): ?> value="<?php echo e(old('work_title', $client->work_title)); ?>" <?php endif; ?> required>
                            <label for="work_title" class="">Επάγγελμα *</label>
                        </div>
                        <div class="input-field col s12 m3">
                            <i class="material-icons prefix">account_circle</i>
                            <input id="name" type="text" name="name" <?php if(isset($client->name)): ?>value="<?php echo e(old('name', $client->name)); ?>" <?php endif; ?> required>
                            <label for="name" class="">Ονοματεπώνυμο Υπευθύνου *</label>
                        </div>

                    </div>
                    <div class="row edra">
                        <div class="input-field col s6 m5">
                            <i class="material-icons prefix">markunread_mailbox</i>
                            <input id="address" type="text" name="address" <?php if(isset($edra)): ?> value="<?php echo e(old('address', $edra->address)); ?>" <?php endif; ?> required>
                            <label for="address" class="">Διεύθυνση Έδρας *</label>
                        </div>
                        <div class="input-field col s6 m2">
                            <i class="material-icons prefix">looks_one</i>
                            <input id="number" type="text" name="number" <?php if(isset($edra->number)): ?> value="<?php echo e(old('number', $edra->number)); ?>" <?php endif; ?> required>
                            <label for="number" class="">Αριθμός *</label>
                        </div>
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">map</i>
                            <input id="city" type="text" name="city" <?php if(isset($edra->city)): ?>  value="<?php echo e(old('city', $edra->city)); ?>" <?php endif; ?> required>
                            <label for="city" class="">Πόλη *</label>
                        </div>
                        <div class="input-field col s6 m2">
                            <i class="material-icons prefix">location_searching

                            </i>
                            <input id="postal_code" type="text" name="postal_code" <?php if(isset($edra->postal_code)): ?>  value="<?php echo e(old('postal_code', $edra->postal_code)); ?>" <?php endif; ?> required>
                            <label for="postal_code" class="">Τ.Κ. *</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">flip</i>
                            <input id="vat" type="text" name="vat" <?php if(isset($client->vat)): ?>  value="<?php echo e(old('vat', $client->vat)); ?>" <?php endif; ?> required>
                            <label for="vat" class="">ΑΦΜ *</label>
                        </div>
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">layers</i>
                            <input id="doy" type="text" name="doy" <?php if(isset($client->doy)): ?>  value="<?php echo e(old('doy', $client->doy)); ?>" <?php endif; ?> required>
                            <label for="doy" class="">ΔΟΥ *</label>
                        </div>
                        <div class="input-field col s6 m6">
                            <i class="material-icons prefix">email</i>
                            <input id="email" type="email" name="email" <?php if(isset($client->email)): ?>  value="<?php echo e(old('email', $client->email)); ?>" <?php endif; ?> required>
                            <label for="email" class="">E-mail Υπευθύνου *</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">phone</i>
                            <input id="phone" type="text" name="phone" <?php if(isset($client->phone)): ?>  value="<?php echo e(old('phone', $client->phone)); ?> <?php endif; ?>">
                            <label for="phone" class="">Τηλέφωνο Εταιρείας</label>
                        </div>
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">phone_iphone</i>
                            <input id="mobile" type="text" name="mobile" <?php if(isset($client->mobile)): ?> value="<?php echo e(old('mobile', $client->mobile)); ?> <?php endif; ?>">
                            <label for="mobile" class="">Κινητό Υπευθύνου Επικοινωνίας</label>
                        </div>
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">email</i>
                            <input id="mail_account" type="email" name="mail_account" <?php if(isset($client->mail_account)): ?> value="<?php echo e(old('mail_account', $client->mail_account)); ?> <?php endif; ?>">
                            <label for="mail_account" class="">E-mail Λογιστηρίου</label>
                        </div>
                        <div class="input-field col s6 m3">
                            <i class="material-icons prefix">contact_phone</i>
                            <input id="phone_account" type="text" name="phone_account" <?php if(isset($client->phone_account)): ?> value="<?php echo e(old('phone_account', $client->phone_account)); ?> <?php endif; ?>">
                            <label for="phone_account" class="">Τηλέφωνο Λογιστηρίου</label>
                        </div>
                    </div>
                    <div class="row adresses-repeater">
                        <h4 class="card-title">Υποκαταστήματα - Αποθήκες</h4>
                        <?php if(isset($client) && $client->addresses): ?>
                            <?php $__currentLoopData = $client->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($add->address_type !== 0): ?>
                                    <div data-address-id="<?php echo e($add->id); ?>">
                                        <div class="mb-1 count-repeater col sm12 width-100">
                                            <div class="input-field col s6 m2">
                                                <i class="material-icons prefix">business</i>
                                                <input type="hidden" name="address_id" value="<?php echo e($add->id); ?>">
                                                <select type="text" name="address_type" required class="invoice-item-select browser-default" style="padding-left: 40px;">
                                                    <option value="Υποκατάστημα" <?php if($add->address_name = 'Υποκατάστημα'): ?> selected <?php endif; ?>>Υποκατάστημα</option>
                                                    <option value="Αποθήκη" <?php if($add->address_name = 'Αποθήκη'): ?> selected <?php endif; ?>>Αποθήκη</option>
                                                </select>
                                            </div>
                                            <div class="input-field col s6 m3">
                                                <i class="material-icons prefix">markunread_mailbox</i>
                                                <input type="text" name="address" placeholder="Διεύθυνση *" value="<?php echo e($add->address); ?>" required>
                                            </div>
                                            <div class="input-field col s6 m1">
                                                <i class="material-icons prefix">looks_one</i>
                                                <input type="text" name="number" placeholder="Αριθμός *" value="<?php echo e($add->number); ?>" required>
                                            </div>
                                            <div class="input-field col s6 m3">
                                                <i class="material-icons prefix">map</i>
                                                <input type="text" name="city" placeholder="Πόλη *" value="<?php echo e($add->city); ?>" required>
                                            </div>
                                            <div class="input-field col s6 m2">
                                                <i class="material-icons prefix">location_searching</i>
                                                <input id="postal_code" type="text" name="postal_code" placeholder="Τ.Κ. *" value="<?php echo e($add->postal_code); ?>" required>
                                            </div>
                                            <div class="invoice-icon display-flex flex-column justify-content-between" style="margin-top: 22px;">
                                              <span class="delete-row-btn delete-address cursor-pointer" data-id="<?php echo e($add->id); ?>">
                                                <i class="material-icons">clear</i>
                                              </span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(isset($client) && count($client->addresses) == 1): ?>
                            <p class="mb-3">Δεν υπάρχουν αποθηκευμένα υποκαταστήματα ή αποθήκες για τον πελάτη <strong><?php echo e($client->company); ?></strong></p>
                        <?php endif; ?>
                        <h4 class="card-title">Προσθήκη Νέας Διεύθυνσης</h4>
                        <div data-repeater-list="addresses">
                            <div class="mb-1 count-repeater col sm12 width-100" data-repeater-item="">
                                <div class="input-field col s6 m2">
                                    <i class="material-icons prefix">business</i>
                                    <select type="text" name="address_type" required class="invoice-item-select browser-default" style="padding-left: 40px;">
                                        <option value="Υποκατάστημα">Υποκατάστημα</option>
                                        <option value="Αποθήκη">Αποθήκη</option>
                                    </select>
                                </div>
                                <div class="input-field col s6 m3">
                                    <i class="material-icons prefix">markunread_mailbox</i>
                                    <input type="text" name="address" placeholder="Διεύθυνση *">
                                </div>
                                <div class="input-field col s6 m1">
                                    <i class="material-icons prefix">looks_one</i>
                                    <input type="text" name="number" placeholder="Αριθμός *">
                                </div>
                                <div class="input-field col s6 m3">
                                    <i class="material-icons prefix">map</i>
                                    <input type="text" name="city" placeholder="Πόλη *">
                                </div>
                                <div class="input-field col s6 m2">
                                    <i class="material-icons prefix">location_searching</i>
                                    <input id="postal_code" type="text" name="postal_code" placeholder="Τ.Κ. *">
                                </div>
                                <div class="invoice-icon display-flex flex-column justify-content-between" style="margin-top: 22px;">
                                  <span data-repeater-delete="" class="delete-row-btn cursor-pointer">
                                    <i class="material-icons">clear</i>
                                  </span>
                                </div>
                            </div>
                        </div>
                        <div class="input-field col s12">
                            <button class="btn invoice-repeat-btn" data-repeater-create="" type="button">
                                <i class="material-icons left">add</i>
                                <span>Προσθήκη Διεύθυνσης</span>
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right" type="submit" name="action"><?php if(isset($client->vat)): ?> Ενημέρωση <?php else: ?> Καταχώρηση <?php endif; ?>
                                <i class="material-icons right">send</i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="ajax-preloader">
        <div class="preloader-wrapper big active">
            <div class="spinner-layer spinner-blue-only">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="gap-patch">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('vendors/form_repeater/jquery.repeater.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script>
        $a = jQuery.noConflict();
        $a(document).ready(function () {
            <?php if(Session::has('notify')): ?>
            M.toast({
                html: '<?php echo e(Session::get("notify")); ?>',
                classes: 'rounded',
                timeout: 10000
            });
            <?php endif; ?>
           $a('input#vat').on('mouseout', function(){
              let afm = $a(this).val();
              if(afm.length > 6) {
                  let pageToken = $a('meta[name="csrf-token"]').attr('content');
                  $a.ajaxSetup({
                      headers: {
                          'X-CSRF-TOKEN': pageToken
                      }
                  });
                  $a.ajax({
                      method: "post",
                      url: "<?php echo e(route('client.vatCheck')); ?>",
                      data: {vat: afm}
                  }).done(function(response){
                        console.log(response);
                  });
              }
           });
            var uniqueId = 1;
            if ($a(".addresses-item-repeater").length) {
                $a(".addresses-item-repeater").repeater({
                    show: function () {
                        /* Assign unique id to new dropdown */
                        $a(this).find(".dropdown-button").attr("data-target", "dropdown-discount" + uniqueId + "");
                        $a(this).find(".dropdown-content").attr("id", "dropdown-discount" + uniqueId + "");
                        uniqueId++;
                        /* showing the new repeater */
                        $a(this).slideDown();
                    },
                    hide: function (deleteElement) {
                        $a(this).slideUp(deleteElement);
                    }
                });
            }


            $a('.delete-address').on('click', function () {
                $a('.ajax-preloader').addClass('active');

                let addressId = $a(this).data('id');

                let pageToken = $a('meta[name="csrf-token"]').attr('content');

                $a.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': pageToken
                    }
                });

                $a.ajax({
                    url: "<?php echo e(url('/delete-address-ajax')); ?>",
                    method: 'post',
                    data: {
                        id: addressId
                    },
                    success: function (result) {
                        console.log(result);
                        $a('.ajax-preloader').removeClass('active');
                        M.toast({
                            html: result,
                            classes: 'rounded',
                            timeout: 10000
                        });
                        $a('div[data-address-id="'+addressId+'"]').remove();
                    }
                });
            });



        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/clients/add.blade.php ENDPATH**/ ?>