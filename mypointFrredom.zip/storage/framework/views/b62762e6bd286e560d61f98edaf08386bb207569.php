<div class="col s12 m6">
    <ul id="task-card" class="collection with-header animate fadeLeft card">
        <li class="collection-header cyan">
            <h5 class="task-card-title mb-3">Υπενθυμίσεις</h5>
            <p class="task-card-date"><?php echo e($today); ?></p>
            <a class="btn-floating activator btn-move-up waves-effect waves-light red accent-2 z-depth-4 right" style="top: -2px;" title="Προθήκη νέας υπενθύμισης">
                <i class="material-icons">add</i>
            </a>
        </li>
        <?php $__currentLoopData = getTasks(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="collection-item dismissable">
            <form class="change-task-state" method="post" action="<?php echo e(route('tasks.state', ['task' => $task])); ?>">
                <?php echo csrf_field(); ?>
                <label>
                    <input type="checkbox" class="change-status" name="taskstatus" <?php if($task->completed == 1): ?> checked <?php endif; ?>>
                    <span class="width-100"<?php if($task->completed == 1): ?> style="text-decoration: line-through;" <?php endif; ?>><?php echo e($task->taskName); ?> </span>
                    <span class="secondary-content"><span class="ultra-small"><?php echo e(Carbon\Carbon::parse($task->task_date)->format('d/m/Y')); ?></span></span>
                    <span class="task-cat teal accent-4"><?php echo e(\Illuminate\Support\Str::limit(getClient($task->client_id)['company'], 50, $end='...')); ?></span>
                </label>
            </form>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="card-reveal">
                            <span class="card-title grey-text text-darken-4">
                                Νέα Υπενθύμιση <i class="material-icons right">close</i>
                            </span>
            <div class="row">
                <form action="<?php echo e(route('tasks.store')); ?>" class="col-12 mt-5" style="overflow-x: hidden">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="input-field col s12">
                            <input name="task_title" id="task_title" type="text" class="validate">
                            <label for="task_title">Τίτλος Υπενθύμισης</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 priority-label">
                            <input name="priority" id="priority" type="range" min="1" max="5" value="5" />
                            <label for="priority">Προτεραιότητα</label>
                            <div class="priority-info">
                                <div class="maximum">Υψηλή</div>
                                <div class="medium">Μέτρια</div>
                                <div class="minimum">Χαμηλή</div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input name="task_date" id="task_date" type="text" class="datepicker">
                            <label for="task_date">Ημ/νία Υπενθύμισης</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <textarea name="description" id="description" class="materialize-textarea"></textarea>
                            <label for="description">Περιγραφή</label>
                        </div>
                    </div>
                    <div class="input-field col s12" >
                        <select id="taskClient" name="taskClient" class="browser-default" style="position: relative">
                            <option value="" disabled selected>Επιλέξτε πελάτη</option>
                            <?php $__currentLoopData = clientsNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $clientName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($clientName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="taskClient" style="top: -30px;">Αφορά τον πελάτη (μη υποχρεωτικό)</label>
                    </div>
                    <div class="row">
                        <button class="btn waves-effect waves-light" type="submit">Καταχώρηση
                            <i class="material-icons right">save</i>
                        </button>
                    </div>

                </form>
            </div>

        </div>
    </ul>
</div>
<?php $__env->startSection('last-script'); ?>
    <script>
        $t = jQuery.noConflict();
        $t(document).ready(function(){
            $t('input.change-status').on('change', function() {
                $t(this).parent().parent('form').submit();
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/pages/parts/homepage-tasks.blade.php ENDPATH**/ ?>