<div id="addresses">
    <div class="card-panel">
        <div class="row">
            <form action="<?php echo e(route('settings.update', ['form' => 'addresses'])); ?>" method="post" enctype="multipart/form-data" class="form invoice-item-repeater">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div>
                        <div class="addresses-item position-relative">
                            <div class="col s3">
                                <div class="input-field">
                                    <select name="<?php echo e($address['type']); ?>" class="invoice-item-select browser-default">
                                        <option value="0_edra" <?php if($address['type'] == 'address_0_edra'): ?> selected <?php endif; ?>>Έδρα</option>
                                        <option value="1_ypokatastima" <?php if($address['type'] == 'address_1_ypokatastima'): ?> selected <?php endif; ?>>Υποκατάστημα 1</option>
                                        <option value="2_ypokatastima" <?php if($address['type'] == 'address_2_ypokatastima'): ?> selected <?php endif; ?>>Υποκατάστημα 2</option>
                                        <option value="3_ypokatastima" <?php if($address['type'] == 'address_3_ypokatastima'): ?> selected <?php endif; ?>>Υποκατάστημα 3</option>
                                        <option value="4_ypokatastima" <?php if($address['type'] == 'address_4_ypokatastima'): ?> selected <?php endif; ?>>Υποκατάστημα 4</option>
                                        <option value="5_ypokatastima" <?php if($address['type'] == 'address_5_ypokatastima'): ?> selected <?php endif; ?>>Υποκατάστημα 5</option>
                                        <option value="1_apothiki" <?php if($address['type'] == 'address_1_apothiki'): ?> selected <?php endif; ?>>Αποθήκη 1</option>
                                        <option value="2_apothiki" <?php if($address['type'] == 'address_2_apothiki'): ?> selected <?php endif; ?>>Αποθήκη 2</option>
                                        <option value="3_apothiki" <?php if($address['type'] == 'address_3_apothiki'): ?> selected <?php endif; ?>>Αποθήκη 3</option>
                                        <option value="4_apothiki" <?php if($address['type'] == 'address_4_apothiki'): ?> selected <?php endif; ?>>Αποθήκη 4</option>
                                        <option value="5_apothiki" <?php if($address['type'] == 'address_5_apothiki'): ?> selected <?php endif; ?>>Αποθήκη 5</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col s9">
                                <div class="input-field">
                                    <input id="address" name="<?php echo e($address['type']); ?>" type="text" <?php if(isset($address->value)): ?> value="<?php echo e(old('file', $address->value)); ?>" <?php endif; ?>>
                                    <label for="<?php echo e($address['type']); ?>">Διεύθυνση (Οδός Αριθμός, ΤΚ, Περιοχή, Πόλη)</label>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h4 style="font-size: 16px;font-weight: 400;margin: 45px 0 10px 25px;">Προσθήκη Νέων Διευθύνσεων</h4>
                <div  data-repeater-list="addresses">
                    <div class="addresses-item position-relative" data-repeater-item="">
                        <div class="col s3">
                            <div class="input-field">
                                <select name="address_type" class="invoice-item-select browser-default">
                                    <option value="0_edra">Έδρα</option>
                                    <option value="1_ypokatastima">Υποκατάστημα 1</option>
                                    <option value="2_ypokatastima">Υποκατάστημα 2</option>
                                    <option value="3_ypokatastima">Υποκατάστημα 3</option>
                                    <option value="4_ypokatastima">Υποκατάστημα 4</option>
                                    <option value="5_ypokatastima">Υποκατάστημα 5</option>
                                    <option value="1_apothiki">Αποθήκη 1</option>
                                    <option value="2_apothiki">Αποθήκη 2</option>
                                    <option value="3_apothiki">Αποθήκη 3</option>
                                    <option value="4_apothiki">Αποθήκη 4</option>
                                    <option value="5_apothiki">Αποθήκη 5</option>
                                </select>
                            </div>
                        </div>
                        <div class="col s9">
                            <div class="input-field">
                                <input id="address" name="address" type="text" <?php if(isset($settings['address'])): ?> value="<?php echo e($settings['address']); ?>" <?php endif; ?>>
                                <label for="address">Διεύθυνση (Οδός Αριθμός, ΤΚ, Περιοχή, Πόλη)</label>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>

                <div class="input-field">
                    <button class="btn invoice-repeat-btn" data-repeater-create="" type="button">
                        <i class="material-icons left">add</i>
                        <span>Προσθήκη Γραμμής</span>
                    </button>
                </div>
                <div class="col s12 display-flex justify-content-end form-action">
                    <button type="submit" class="btn indigo waves-effect waves-light mr-1">Αποθήκευση Αλλαγών</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/settings/addresses.blade.php ENDPATH**/ ?>