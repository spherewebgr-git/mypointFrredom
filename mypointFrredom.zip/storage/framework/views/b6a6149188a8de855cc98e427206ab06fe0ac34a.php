<?php $trashed = getTrashed(); ?>
<div class="navbar <?php if(($configData['isNavbarFixed'])=== true): ?><?php echo e('navbar-fixed'); ?> <?php endif; ?>">
  <nav
    class="<?php echo e($configData['navbarMainClass']); ?> <?php if($configData['isNavbarDark']=== true): ?> <?php echo e('navbar-dark'); ?> <?php elseif($configData['isNavbarDark']=== false): ?> <?php echo e('navbar-light'); ?> <?php elseif(!empty($configData['navbarBgColor'])): ?> <?php echo e($configData['navbarBgColor']); ?> <?php else: ?> <?php echo e($configData['navbarMainColor']); ?> <?php endif; ?>">
    <div class="nav-wrapper">
        <?php echo $__env->yieldContent('header-left'); ?>
      <ul class="navbar-list right">
          <li class="hide-on-med-and-down">
              <div class="waves-effect waves-block waves-light" id="tour">
                  <i class="material-icons">slideshow</i>
              </div>
          </li>
        <li class="hide-on-med-and-down">
          <a class="waves-effect waves-block waves-light toggle-fullscreen" href="javascript:void(0);">
            <i class="material-icons">settings_overscan</i>
          </a>
        </li>
        <li class="hide-on-large-only search-input-wrapper">
          <a class="waves-effect waves-block waves-light search-button" href="javascript:void(0);">
            <i class="material-icons">search</i>
          </a>
        </li>
          <li>
              <a class="waves-effect waves-block waves-light notification-button" href="javascript:void(0);"
                 data-target="binDropdown">
                  <i class="material-icons">delete<small class="notification-badge"><?php echo e(count($trashed)); ?></small></i>
              </a>
          </li>
        <li>
          <a class="waves-effect waves-block waves-light profile-button" href="javascript:void(0);" title="<?php echo e(settings()['company']. ' - ' . settings()['title']); ?>"
            data-target="profile-dropdown">
              <?php if(isset(settings()['logo'])): ?>
                <span class="avatar-status avatar-online">
                  <img src="<?php echo e(asset('images/system/'.settings()['logo'])); ?>" alt="<?php echo e(settings()['company']); ?> Logo"><i></i>
                </span>
                  <?php else: ?>
                  <span id="avatar-name"><?php echo e(settings()['company']); ?></span>
              <?php endif; ?>
          </a>
        </li>
      </ul>
      <!-- notifications-dropdown-->
      <ul class="dropdown-content" id="binDropdown">
        <li>
          <h6>ΚΑΔΟΣ ΑΝΑΚΥΚΛΩΣΗΣ</h6>
        </li>
        <li class="divider"></li>
          <?php $__currentLoopData = $trashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trash): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                  <?php if(isset($trash->invoiceID)): ?>
                  <div class="black-text">
                  <span class="material-icons icon-bg-circle cyan small">add_shopping_cart</span>
                      Τιμολόγιο - m<?php echo e(str_pad($trash->invoiceID, 4, '0', STR_PAD_LEFT)); ?>

                  </div>
                  <time class="media-meta grey-text darken-2" datetime="2015-06-12T20:50:48+08:00">Διεγράφη <?php echo e(\Carbon\Carbon::parse($trash->deleted_at)->format('d/m/Y')); ?> - <?php echo e(\Carbon\Carbon::parse($trash->deleted_at)->format('H:i')); ?></time>
                  <?php else: ?>
                  <div class="black-text">
                      <span class="material-icons icon-bg-circle cyan small">receipt</span>
                      <?php echo e($trash->outcome_number); ?> - <?php echo e($trash->shop); ?>

                  </div>
                  <time class="media-meta grey-text darken-2" datetime="2015-06-12T20:50:48+08:00">Διεγράφη <?php echo e(\Carbon\Carbon::parse($trash->deleted_at)->format('d/m/Y')); ?> - <?php echo e(\Carbon\Carbon::parse($trash->deleted_at)->format('H:i')); ?></time>
                  <?php endif; ?>
              </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <!-- profile-dropdown-->
      <ul class="dropdown-content" id="profile-dropdown">
        <li>
          <a class="grey-text text-darken-1" href="#">
            <i class="material-icons">help_outline</i>
            Help
          </a>
        </li>
        <li class="divider"></li>
        <li>
          <a class="grey-text text-darken-1" href="<?php echo e(route('signOut')); ?>">
            <i class="material-icons">keyboard_tab</i>
            Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
</div>
<?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/panels/navbar.blade.php ENDPATH**/ ?>