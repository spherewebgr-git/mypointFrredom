



<?php $__env->startSection('title','Καταχώρηση νέου προμηθευτή'); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
        <!-- Search for small screen-->
        <div class="container">
            <div class="row">
                <div class="col s10 m6 l6">
                    <h5 class="breadcrumbs-title mt-0 mb-0"><span>Καταχώρηση νέου προμηθευτή</span></h5>
                </div>
            </div>
        </div>
    </div>
    <div class="col s12 m12 l12">
        <div id="prefixes" class="card card card-default scrollspy">
            <div class="card-content">
                <h4 class="card-title">Στοιχεία Προμηθευτή</h4>
                <form <?php if(isset($provider)): ?> action="<?php echo e(route('provider.update', ['provider' => $provider])); ?>" <?php else: ?> action="<?php echo e(route('provider.store')); ?>" <?php endif; ?> method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="input-field col s12 m5">
                            <i class="material-icons prefix">account_circle</i>
                            <input id="provider_id" type="text" name="provider_id" <?php if(isset($provider->provider_id)): ?>value="<?php echo e(old('provider_id', $provider->provider_id)); ?>"  <?php else: ?> value="<?php echo e($number); ?>" <?php endif; ?> required>
                            <label for="provider_id" class="">Κωδικός Προμηθευτή *</label>
                        </div>
                        <div class="input-field col s12 m7">
                            <i class="material-icons prefix">business_center</i>
                            <input id="provider_name" type="text" name="provider_name" <?php if(isset($provider->provider_name)): ?> value="<?php echo e(old('provider_name', $provider->provider_name)); ?>" <?php endif; ?> required>
                            <label for="provider_name" class="">Επωνυμία Προμηθευτή*</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6 m4">
                            <i class="material-icons prefix">markunread_mailbox</i>
                            <input id="address" type="text" name="address" <?php if(isset($provider->address)): ?> value="<?php echo e(old('address', $provider->address)); ?>" <?php endif; ?> required>
                            <label for="address" class="">Διεύθυνση Έδρας προμηθευτή *</label>
                        </div>
                        <div class="input-field col s6 m2">
                            <i class="material-icons prefix">markunread_mailbox</i>
                            <input id="address_number" type="text" name="address_number" <?php if(isset($provider->address_number)): ?> value="<?php echo e(old('address_number', $provider->address_number)); ?>" <?php endif; ?> required>
                            <label for="address_number" class="">Αριθμός *</label>
                        </div>
                        <div class="input-field col s6 m4">
                            <i class="material-icons prefix">map</i>
                            <input id="city" type="text" name="city" <?php if(isset($provider->city)): ?>  value="<?php echo e(old('city', $provider->city)); ?>" <?php endif; ?> required>
                            <label for="city" class="">Πόλη *</label>
                        </div>
                        <div class="input-field col s6 m2">
                            <i class="material-icons prefix">map</i>
                            <input id="address_tk" type="text" name="address_tk" <?php if(isset($provider->address_tk)): ?>  value="<?php echo e(old('address_tk', $provider->address_tk)); ?>" <?php endif; ?> required>
                            <label for="address_tk" class="">Τ.Κ. *</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6 m6">
                            <i class="material-icons prefix">flip</i>
                            <input id="provider_vat" type="text" name="provider_vat" <?php if(isset($provider->provider_vat)): ?>  value="<?php echo e(old('provider_vat', $provider->provider_vat)); ?>" <?php endif; ?> required>
                            <label for="provider_vat" class="">ΑΦΜ *</label>
                        </div>
                        <div class="input-field col s6 m6">
                            <i class="material-icons prefix">layers</i>
                            <input id="provider_doy" type="text" name="provider_doy" <?php if(isset($provider->provider_doy)): ?>  value="<?php echo e(old('doy', $provider->provider_doy)); ?>" <?php endif; ?> required>
                            <label for="provider_doy" class="">ΔΟΥ *</label>
                        </div>
                        <div class="input-field col s6 m6">
                            <i class="material-icons prefix">email</i>
                            <input id="email" type="email" name="email" <?php if(isset($provider->email)): ?>  value="<?php echo e(old('email', $provider->email)); ?>" <?php endif; ?>>
                            <label for="email" class="">E-mail Προμηθευτή</label>
                        </div>
                        <div class="input-field col s6 m6">
                            <i class="material-icons prefix">phone</i>
                            <input id="phone" type="text" name="phone" <?php if(isset($provider->phone)): ?>  value="<?php echo e(old('phone', $provider->phone)); ?> <?php endif; ?>">
                            <label for="phone" class="">Τηλέφωνο Προμηθευτή</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <button class="btn cyan waves-effect waves-light right" type="submit" name="action"><?php if(isset($provider->provider_vat)): ?> Ενημέρωση <?php else: ?> Καταχώρηση <?php endif; ?>
                                <i class="material-icons right">send</i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('vendor-script'); ?>
    <script src="<?php echo e(asset('vendors/data-tables/js/jquery.dataTables.js')); ?>"></script>
    <script>
        <?php if(Session::has('notify')): ?>
        M.toast({
            html: '<?php echo e(Session::get("notify")); ?>',
            classes: 'rounded',
            timeout: 10000
        });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/providers/add.blade.php ENDPATH**/ ?>