<?php $__env->startSection('title','Λίστα Τιμολογίων Παροχής Υπηρεσιών'); ?>

<?php $__env->startSection('header-left'); ?>
    <a href="#" class="btn waves-effect waves-light invoices-myData border-round z-depth-4 hide" style="margin-left: 270px;line-height: 2.4rem;">
        <span>Απόστολή στο myData</span>
    </a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
        <!-- Search for small screen-->
        <div class="container">
            <div class="row">
                <div class="col s10 m6 l6">
                    <h5 class="breadcrumbs-title mt-0 mb-0"><span>Λίστα Τιμολογίων Παροχής Υπηρεσιών</span></h5>
                </div>
                <div class="invoice-head--right row col s12 m6 display-flex justify-content-end align-items-center">
                    <div class="invoice-create-btn col">
                        <a href="<?php echo e(route('invoice.create')); ?>"
                           class="btn waves-effect waves-light invoice-create border-round z-depth-4">
                            <i class="material-icons">add</i>
                            <span>Νέο Τιμολόγιο</span>
                        </a>
                    </div>
                    <div class="invoice-filter-action col">
                        <a href="javascript:if(window.print)window.print()" class="btn waves-effect waves-light invoice-export border-round z-depth-4">
                            <i class="material-icons">print</i>
                            <span>Εκτύπωση Λίστας</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="invoice-list-wrapper section">
        <div class="responsive-table">
            <div class="card print-hide">
                <div class="card-content container">
                    <h4 class="card-title">Αναζήτηση Βάσει Ημερομηνίας</h4>
                    <form action="<?php echo e(route('invoice.filter')); ?>" method="post" class="row display-flex flex-wrap align-items-center justify-content-between invoice-head">
                        <?php echo csrf_field(); ?>
                        <div class="invoice-head--left row display-flex col align-items-center">
                            <label for="start" class="col display-flex align-items-center justify-content-end"><i class="material-icons">date_range</i> Από:</label>
                            <div class="col">
                                <input type="text" id="datepickerStart" name="date-start" class="datepicker"
                                       value="<?php if(isset($dateStart)): ?><?php echo e(date('d/m/Y', strtotime($dateStart))); ?><?php else: ?> 01/01/<?php echo e(date('Y')); ?> <?php endif; ?>"
                                       title="Φίλτρο από:">
                            </div>
                            <label for="end" class="col display-flex align-items-center justify-content-end"><i class="material-icons">date_range</i> Έως: </label>
                            <div class="col">
                                <input type="text" id="datepickerEnd" name="date-end" class="datepicker"
                                       value="<?php if(isset($dateEnd)): ?><?php echo e(date('d/m/Y', strtotime($dateEnd))); ?><?php else: ?><?php echo e(date('d/m/Y')); ?><?php endif; ?>"
                                       title="Φίλτρο εως:">
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-xs btn-info filter-btn display-flex align-items-center border-round z-depth-4">
                                    <i class="material-icons" style="margin-right: 5px;">search</i> <span>Προσαρμογή Φίλτρου</span></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper no-footer">
                <div class="top display-flex mb-2" style="display: none">
                    <div class="action-filters">
                        <div id="DataTables_Table_0_filter" class="dataTables_filter">
                            <label>
                                <input type="search" class="" placeholder="Αναζήτηση τιμολογίου"
                                       aria-controls="DataTables_Table_0">
                                <div class="filter-btn">
                                    <!-- Dropdown Trigger -->
                                    <a class="dropdown-trigger btn waves-effect waves-light purple darken-1 border-round"
                                       href="#" data-target="btn-filter">
                                        <span class="hide-on-small-only">Κατάσταση</span>
                                        <i class="material-icons">keyboard_arrow_down</i>
                                    </a>
                                    <ul id="btn-filter" class="dropdown-content " tabindex="0" style="">
                                        <li tabindex="0"><a href="#!">Πληρωμένο</a></li>
                                        <li tabindex="0"><a href="#!">Απλήρωτο</a></li>
                                        <li tabindex="0"><a href="#!">Προκαταβολή</a></li>
                                    </ul>
                                    <!-- Dropdown Structure -->
                                </div>
                            </label>
                        </div>
                    </div>
                    <div class="actions action-btns display-flex align-items-center">
                        <div class="invoice-filter-action mr-3">
                            <a href="#" class="btn waves-effect waves-light invoice-export border-round z-depth-4">
                                <i class="material-icons">picture_as_pdf</i>
                                <span class="hide-on-small-only">Export to PDF</span>
                            </a>
                        </div>
                        <div class="invoice-create-btn">
                            <a href="<?php echo e(route('invoice.create')); ?>"
                               class="btn waves-effect waves-light invoice-create border-round z-depth-4">
                                <i class="material-icons">add</i>
                                <span class="hide-on-small-only">Create Invoice</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
                <div class="table-container">
                    <table class="table invoice-data-table white border-radius-4 pt-1 dataTable no-footer dtr-column"
                           id="DataTables_Table_0" role="grid">
                        <thead>
                        <tr role="row">
                            <th class="control sorting_disabled" rowspan="1" colspan="1"
                                style="width: 19.8906px; display: none;" aria-label=""></th>
                            <th class="invoices-select-all center"><label>
                                    <input type="checkbox" class="select-all-myData" name="myDataAll">
                                    <span></span>
                                </label></th>
                            <th class="center-align">
                                <span>Τ.Π.Υ.</span>
                            </th>
                            <th>Πελάτης</th>
                            <th class="center-align">Ημ/νία Έκδοσης</th>
                            <th class="center-align" style="width: 85px!important;">Τιμή</th>
                            <th class="center-align hide-on-med-and-down" style="width: 85px!important;">Παρ/ση</th>
                            <th class="center-align" style="width: 85px!important;">Φ.Π.Α.</th>
                            <th class="center-align print-hide hide-on-med-and-down" style="width: 85px!important;">Σύνολο</th>
                            <th class="center-align print-hide">Κατάσταση</th>
                            <th class="center-align print-hide">Ενέργειες</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="odd">
                                <td class=" control" tabindex="0" style="display: none;"></td>
                                <td class="select-square center">
                                    <label for="send-<?php echo e($invoice->invoiceID); ?>">
                                        <input type="checkbox" data-invoice="<?php echo e($invoice->invoiceID); ?>"  name="send-<?php echo e($invoice->invoiceID); ?>" id="send-<?php echo e($invoice->invoiceID); ?>" <?php if(isset($invoice->mark) && $invoice->mark != null): ?> class="hasmark" checked disabled <?php else: ?> class="myDataSelect" <?php endif; ?>>
                                        <span></span>
                                    </label>
                                </td>
                                <td class="sorting_1 center-align">
                                    <?php if($invoice->seira != 'ANEY'): ?> <?php echo e($invoice->seira); ?> <?php endif; ?> <?php echo e($invoice->invoiceID); ?>

                                </td>
                                <td class="bold">
                                    <a href="<?php echo e(route('client.view', $invoice->client->hashID)); ?>"><?php echo e($invoice->client->company); ?></a>
                                </td>
                                <td class="center-align">
                                    <small><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($invoice->date))->format('d/m/Y')); ?></small>
                                </td>
                                <td class="center-align">
                                    &euro; <?php echo e(number_format(getFinalPrices($invoice->hashID), '2', ',', '.')); ?></td>
                                <td class="center-align count-parakratisi hide-on-med-and-down" <?php if(getFinalPrices($invoice->hashID) > 300 && $invoice->has_parakratisi == 1): ?> data-price="<?php echo e((20 / 100) * getFinalPrices($invoice->hashID)); ?>" <?php endif; ?>>
                                    <?php if(getFinalPrices($invoice->hashID) > 300 && $invoice->has_parakratisi == 1): ?>
                                    &euro; <?php echo e(number_format((20 / 100) * getFinalPrices($invoice->hashID), '2', ',', '.')); ?>


                                        <?php else: ?>
                                        <span class="bullet blue"></span>
                                    <?php endif; ?>
                                </td>
                                <td class="center-align print-hide">
                                    &euro; <?php echo e(number_format((24 / 100) * getFinalPrices($invoice->hashID), '2', ',', '.')); ?>

                                </td>
                                <td class="center-align hide-on-med-and-down">

                                    &euro; <?php echo e(number_format(getFinalPrices($invoice->hashID) + ((24 / 100) * getFinalPrices($invoice->hashID)), '2', ',', '.')); ?>


                                </td>
                                <td class="center-align print-hide">
                                    <?php if($invoice->paid == 1): ?>
                                        <span class="chip lighten-5 green green-text">ΠΛΗΡΩΜΕΝΟ</span>
                                    <?php elseif($invoice->paid == 0): ?>
                                        <span class="chip lighten-5 red red-text">ΑΠΛΗΡΩΤΟ</span>
                                    <?php else: ?>
                                        <span class="chip lighten-5 orange orange-text">Προκαταβολή</span>
                                    <?php endif; ?>
                                </td>
                                <td class="center-align print-hide">
                                    <div class="invoice-action">
                                        <?php if($invoice->mark): ?>
                                            <a href="<?php echo e(route('invoice.view', ['invoice' => $invoice->hashID])); ?>" class="invoice-action-view mr-4">
                                                <i class="material-icons">remove_red_eye</i>
                                            </a>
                                            <a href="<?php echo e(route('invoice.download', $invoice->hashID)); ?>" class="invoice-action-view mr-4">
                                                <i class="material-icons">cloud_download</i>
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('invoice.view', ['invoice' => $invoice->hashID])); ?>" class="invoice-action-view mr-4">
                                                <i class="material-icons">remove_red_eye</i>
                                            </a>
                                            <a href="<?php echo e(route('invoice.edit', ['invoice' => $invoice->hashID])); ?>" class="invoice-action-edit">
                                                <i class="material-icons">edit</i>
                                            </a>
                                            <a href="<?php echo e(route('invoice.delete', ['invoice' => $invoice->hashID])); ?>" class="invoice-action-edit">
                                                <i class="material-icons">delete</i>
                                            </a>
                                        <?php endif; ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="finals gradient-45deg-indigo-blue">
                            <td></td>
                            <td colspan="3" class="right-align">Σύνολα:</td>
                            <td class="center-align tooltipped" data-position="top" data-tooltip="Σύνολο Εσόδων">&euro; <?php echo e(number_format($finals, '2', ',', '.')); ?></td>
                            <td class="center-align parakratisi-synolo tooltipped" data-position="top" data-tooltip="Σύνολο Παρακράτησης Φόρου"></td>
                            <td class="center-align tooltipped" data-position="top" data-tooltip="Σύνολο Φ.Π.Α.">&euro; <?php echo e(number_format(((24 / 100) * $finals),  2, ',', '.')); ?></td>

                            <td colspan="3" class="tooltipped print-hide" data-position="top" data-tooltip="Σύνολο Μικτό">&euro; <?php echo e(number_format(($finals + ((24 / 100) * $finals)), 2, ',', '.' )); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/scripts/app-invoice.js')); ?>"></script>
    <script>
        $m = jQuery.noConflict();
        $m(document).ready(function () {
            <?php if(Session::has('notify')): ?>
            M.toast({
                html: '<?php echo e(Session::get("notify")); ?>',
                classes: 'rounded',
                timeout: 10000
            });
            <?php endif; ?>

            var parakratiseis = 0;
            $m('.count-parakratisi').each(function(){
                let price = $m(this).data('price');
                if(typeof price !== 'undefined'){
                    parakratiseis += parseInt(price);
                }
            });
            $m('.parakratisi-synolo').text('€ '+ custom_number_format(parakratiseis, '2'));

            $m('.select-all-myData').on('change', function(){
                $m('input.myDataSelect').each(function(){
                   $m(this).attr('checked', !$m(this).prop('checked'));
                });
                $m('a.invoices-myData').toggleClass('hide');
            });

            $m('input.myDataSelect').on('change', function(){
                if($m('input.myDataSelect').is(':checked')) {
                    $m('a.invoices-myData').removeClass('hide');
                } else {
                    $m('a.invoices-myData').addClass('hide');
                }
            });
            $m('a.invoices-myData').on('click', function(e){
                e.preventDefault();
               let invoiceIds = [];
                $m('input.myDataSelect:checked').each(function(){
                    let invoiceId = $m(this).data('invoice');
                    invoiceIds.push(invoiceId);
                })
                $m.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $m('meta[name="csrf-token"]').attr('content')
                    }
                });
                $m.ajax({
                    url: "<?php echo e(route('invoice.mydata.multiple')); ?>",
                    method: 'POST',
                    data: { ids: invoiceIds},
                    success: function(result) {
                        console.log(result);
                    }
                });
            });
        });


        function custom_number_format( number_input, decimals, dec_point, thousands_sep ) {
            var number       = ( number_input + '' ).replace( /[^0-9+\-Ee.]/g, '' );
            var finite_number   = !isFinite( +number ) ? 0 : +number;
            var finite_decimals = !isFinite( +decimals ) ? 0 : Math.abs( decimals );
            var seperater     = ( typeof thousands_sep === 'undefined' ) ? ',' : thousands_sep;
            var decimal_pont   = ( typeof dec_point === 'undefined' ) ? '.' : dec_point;
            var number_output   = '';
            var toFixedFix = function ( n, prec ) {
                if( ( '' + n ).indexOf( 'e' ) === -1 ) {
                    return +( Math.round( n + 'e+' + prec ) + 'e-' + prec );
                } else {
                    var arr = ( '' + n ).split( 'e' );
                    let sig = '';
                    if ( +arr[1] + prec > 0 ) {
                        sig = '+';
                    }
                    return ( +(Math.round( +arr[0] + 'e' + sig + ( +arr[1] + prec ) ) + 'e-' + prec ) ).toFixed( prec );
                }
            }
            number_output = ( finite_decimals ? toFixedFix( finite_number, finite_decimals ).toString() : '' + Math.round( finite_number ) ).split( '.' );
            if( number_output[0].length > 3 ) {
                number_output[0] = number_output[0].replace( /\B(?=(?:\d{3})+(?!\d))/g, seperater );
            }
            if( ( number_output[1] || '' ).length < finite_decimals ) {
                number_output[1] = number_output[1] || '';
                number_output[1] += new Array( finite_decimals - number_output[1].length + 1 ).join( '0' );
            }
            return number_output.join( decimal_pont );
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/invoices/index.blade.php ENDPATH**/ ?>