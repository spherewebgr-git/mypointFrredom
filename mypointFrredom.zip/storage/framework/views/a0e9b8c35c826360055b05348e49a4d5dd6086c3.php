<?php $__env->startSection('title','Αποθήκη Προϊόντων'); ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
        <!-- Search for small screen-->
        <div class="container">
            <div class="row">
                <div class="col s10 m6 l6">
                    <h5 class="breadcrumbs-title mt-0 mb-0"><span>Αποθήκη Προϊόντων</span></h5>
                </div>
                <div class="invoice-head--right row col s12 m6 display-flex justify-content-end align-items-center">
                    <div class="invoice-create-btn col">
                        <a href="<?php echo e(route('products.create')); ?>"
                           class="btn waves-effect waves-light invoice-create border-round z-depth-4">
                            <i class="material-icons">add</i>
                            <span>Νέο Προϊόν</span>
                        </a>
                    </div>
                    <div class="invoice-filter-action col">
                        <a href="javascript:if(window.print)window.print()" class="btn waves-effect waves-light invoice-export border-round z-depth-4">
                            <i class="material-icons">print</i>
                            <span>Εκτύπωση Λίστας</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card print-hide">
        <div class="card-content container">
            <h4 class="card-title">Αναζήτηση Προϊόντος</h4>
        </div>
    </div>
    <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper no-footer">
        <table class="table invoice-data-table white border-radius-4 pt-1 dataTable no-footer dtr-column"
               id="DataTables_Table_0" role="grid" style="border-spacing: 0 5px;">
            <thead>
            <tr role="row">
                <th class="control sorting_disabled" rowspan="1" colspan="1"
                    style="width: 19.8906px; display: none;" aria-label=""></th>
                <th class="center-align">Εικόνα</th>
                <th class="center-align"><span>Κωδ. Προϊόντος</span></th>
                <th>Τίτλος</th>
                <th class="center-align" style="width: 85px!important;">Τιμή</th>
                <th class="center-align" style="width: 85px!important;">Φ.Π.Α.</th>
                <th class="center-align" style="width: 85px!important;">Ποσότητα</th>
                <th class="center-align" style="width: 85px!important;">Κατάσταση</th>
                <th class="center-align print-hide">Ενέργειες</th>
            </tr>
            </thead>
            <tbody>
                <?php if(isset($products)): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($product->active ? 'active' : 'inactive'); ?>">
                        <td class="center-align"><?php if(isset($product->product_image)): ?><img src="<?php echo e(url('images/products/'.$product->product_image)); ?>" alt=""  style="max-height: 80px;max-width: 200px;" /><?php endif; ?></td>
                        <td class="center-align"><?php echo e($product->product_number); ?></td>
                        <td><?php echo e($product->product_name); ?></td>
                        <td class="center-align">&euro; <?php echo e(number_format($product->price, '2', ',', '.')); ?></td>
                        <td class="center-align">&euro; <?php echo e(number_format($product->vat_price, '2', ',', '.')); ?></td>
                        <td class="center-align"><?php echo e($product->storage->quantity); ?></td>
                        <td class="center-align"><?php echo e($product->active ? 'ΕΝΕΡΓΟ' : 'ΑΝΕΝΕΡΓΟ'); ?></td>
                        <td class="center-align print-hide">
                            <div class="invoice-action">
                                <a href="#modal" class="invoice-action-view mr-4 modal-trigger"
                                   data-product-img="<?php echo e(url('images/products/'.$product->product_image)); ?>"
                                   data-product-name="<?php echo e($product->product_name); ?>"
                                   data-product-number="<?php echo e($product->product_number); ?>"
                                   data-category="<?php echo e($product->product_category); ?>"
                                   data-active="<?php echo e($product->active ? '<span class="green">ΕΝΕΡΓΟ</span>' : '<span class="red">ΑΝΕΝΕΡΓΟ</span>'); ?>"
                                   data-quantity="<?php echo e($product->storage->quantity); ?>"
                                   data-price="&euro; <?php echo e(number_format($product->price, '2', ',', '.')); ?>"
                                   data-vat-price="&euro; <?php echo e(number_format($product->vat_price, '2', ',', '.')); ?>"
                                   data-description="<?php echo e($product->product_description); ?>"
                                >
                                    <i class="material-icons">remove_red_eye</i>
                                </a>
                                <a href="<?php echo e(route('products.edit', $product->product_number)); ?>" class="invoice-action-edit">
                                    <i class="material-icons">edit</i>
                                </a>
                                <a href="/" class="invoice-action-edit">
                                    <i class="material-icons">delete</i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="modal" class="modal" tabindex="0" style="z-index: 1003; display: none; opacity: 0; top: 4%; transform: scaleX(0.8) scaleY(0.8);">
                    <div class="modal-content pt-2">
                        <div class="row" id="product-one">
                            <div class="col s12">
                                <a class="modal-close right"><i class="material-icons">close</i></a>
                            </div>
                            <div class="col m6 s12">
                                <img src="" class="responsive-img modal-image" alt="">
                            </div>
                            <div class="col m6 s12">
                                <p class="modal-category"></p>
                                <h5 class="modal-product-name"></h5>
                                <span class="green badge left ml-0 mr-2 modal-active"></span>
                                <p>Απόθεμα: <span class="modal-quantity fw-bolder"></span></p>
                                <hr class="mb-5">
                                <p class="modal-description"></p>
                                <h5 class="modal-price"></h5>


                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-script'); ?>

<script>
    $m = jQuery.noConflict();
    $m(document).ready(function() {
        $m('.modal').modal();
        $m('.modal-trigger').on('click', function(){
           let productImg = $m(this).data('product-img');
           let productName = $m(this).data('product-name');
           let productNumber = $m(this).data('product-number');
           let quantity = $m(this).data('quantity');
           let category = $m(this).data('category');
           let status = $m(this).data('active');
           let productDescription = $m(this).data('description');
           let productPrice = $m(this).data('price');
           let productVatPrice = $m(this).data('vat-price');

           $m('#modal .modal-image').attr('src', productImg);
           $m('#modal .modal-image').attr('alt', productName);
           $m('#modal .modal-quantity').text(quantity);
           $m('#modal .modal-category').text(category);
           $m('#modal .modal-price').html(productPrice+'<small class="ml-2">ΦΠΑ: <span class="prise-text-style modal-vat">'+productVatPrice+'</span></small>');
           $m('#modal .modal-active').html(status);
           $m('#modal .modal-description').html(productDescription);
           $m('#modal .modal-product-name').html(productName+' <span class="modal-code small">('+productNumber+')</span>');

        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/products/index.blade.php ENDPATH**/ ?>