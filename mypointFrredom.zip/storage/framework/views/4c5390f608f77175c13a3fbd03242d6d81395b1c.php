<?php if(isset($product)): ?>
    <?php $__env->startSection('title','Επεξεργασία Καταχώρησης Προϊόντος'); ?>
<?php else: ?>
    <?php $__env->startSection('title','Καταχώρηση Νέου Προϊόντος'); ?>
<?php endif; ?>


<?php $__env->startSection('page-style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/data-tables/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/app-invoice.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
        <!-- Search for small screen-->
        <div class="container">
            <div class="row">
                <div class="col s10 m6 l6">
                    <h5 class="breadcrumbs-title mt-0 mb-0">
                        <?php if(isset($product)): ?>
                            <span>Επεξεργασία Καταχώρησης Προϊόντος</span>
                        <?php else: ?>
                            <span>Καταχώρηση Νέου Προϊόντος</span>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="invoice-head--right row col s12 m6 display-flex justify-content-end align-items-center">
                </div>
            </div>
        </div>
    </div>
    <section class="invoice-edit-wrapper section">
        <div class="row">
            <!-- product add/edit page -->
            <form class="form" <?php if(isset($product)): ?> action="<?php echo e(route('products.update')); ?>" <?php else: ?> action="<?php echo e(route('products.store')); ?>" <?php endif; ?> method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col xl9 m8 s12">
                    <?php if(isset($product)): ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>" />
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-content px-36">
                            <div class="progress" style="display: none">
                                <div class="indeterminate"></div>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="row mb-2">
                                <div class="col s12 m6">
                                    <div class="input-field">
                                        <input type="text" id="product_name" name="product_name" <?php if(isset($product)): ?> value="<?php echo e($product['product_name']); ?>" <?php endif; ?> required>
                                        <label for="product_name">Ονομασία Προϊόντος *</label>
                                    </div>
                                </div>
                                <div class="col s6 m4">
                                    <div class="input-field">
                                        <input type="text" id="product_number" name="product_number" <?php if(isset($product)): ?> value="<?php echo e($product['product_number']); ?>" <?php endif; ?> required>
                                        <label for="product_number">Κωδικός Προϊόντος *</label>
                                    </div>
                                </div>
                                <div class="col s6 m2">
                                    <?php if(isset($product)): ?>
                                        <div class="product-storage">
                                            <div class="product-storage--label">Απόθεμα</div>
                                            <div class="product-storage--quantity"><?php echo e($product->storage->quantity); ?></div>
                                        </div>
                                    <?php else: ?>
                                        <div class="input-field">
                                            <input type="number" id="quantity" name="quantity"  required>
                                            <label for="quantity">Ποσότητα *</label>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col s12 m4">
                                    <div class="input-field">
                                        <i class="material-icons prefix">flip</i>
                                        <input type="text" id="barcode" name="barcode" <?php if(isset($product)): ?> value="<?php echo e($product['barcode']); ?>" <?php endif; ?> >
                                        <label for="barcode">Barcode</label>
                                    </div>
                                </div>
                                <div class="col s12 m3">
                                    <div class="input-field">
                                        <i class="material-icons prefix">archive</i>
                                        <select name="product_category" id="product_category">
                                            <option value="" disabled>Επιλέξτε Κατηγορία</option>
                                            <option value="Κατηγορία 1" <?php if(isset($product) && $product->product_category == 'Κατηγορία 1'): ?> value="<?php echo e($product['product_number']); ?>" <?php endif; ?> >Κατηγορία 1</option>
                                            <option value="Κατηγορία 2" <?php if(isset($product) && $product->product_category == 'Κατηγορία 2'): ?> value="<?php echo e($product['product_number']); ?>" <?php endif; ?> >Κατηγορία 2</option>
                                            <option value="Κατηγορία 3" <?php if(isset($product) && $product->product_category == 'Κατηγορία 3'): ?> value="<?php echo e($product['product_number']); ?>" <?php endif; ?> >Κατηγορία 3</option>
                                            <option value="Κατηγορία 4" <?php if(isset($product) && $product->product_category == 'Κατηγορία 4'): ?> value="<?php echo e($product['product_number']); ?>" <?php endif; ?> >Κατηγορία 4</option>
                                        </select>
                                        <label for="product_category">Κατηγορία</label>
                                    </div>
                                </div>
                                <div class="col s12 m3">
                                    <div class="input-field">
                                        <i class="material-icons prefix">local_grocery_store</i>
                                        <select name="mm_type" id="mm_type">
                                            <option value="" disabled>Επιλέξτε Μονάδα Μέτρησης</option>
                                            <option value="101" <?php if(isset($product) && $product->mm_type == 101): ?> selected <?php endif; ?> >Τεμάχιο</option>
                                            <option value="107" <?php if(isset($product) && $product->mm_type == 107): ?> selected <?php endif; ?> >Κιβώτιο</option>
                                            <option value="120" <?php if(isset($product) && $product->mm_type == 120): ?> selected <?php endif; ?> >Μέτρο</option>
                                            <option value="141" <?php if(isset($product) && $product->mm_type == 141): ?> selected <?php endif; ?> >Λίτρο</option>
                                            <option value="150" <?php if(isset($product) && $product->mm_type == 150): ?> selected <?php endif; ?> >Κιλό</option>
                                        </select>
                                        <label for="mm_type">Μονάδα Μέτρησης (ανά / )</label>
                                    </div>
                                </div>
                                <div class="col s12 m2">
                                    <div class="input-field">
                                        <i class="material-icons prefix">local_grocery_store</i>
                                        <select name="product_vat_id" id="product_vat_id">
                                            <option value="" disabled>Επιλέξτε ΦΠΑ</option>
                                            <option value="1" data-val="24" selected>24%</option>
                                            <option value="2" data-val="13" <?php if(isset($product) && $product->product_vat_id == 2): ?> selected <?php endif; ?> >13%</option>
                                            <option value="3" data-val="6" <?php if(isset($product) && $product->product_vat_id == 3): ?> selected <?php endif; ?> >6%</option>
                                            <option value="4" data-val="17" <?php if(isset($product) && $product->product_vat_id == 4): ?> selected <?php endif; ?> >17%</option>
                                            <option value="5" data-val="9" <?php if(isset($product) && $product->product_vat_id == 5): ?> selected <?php endif; ?> >9%</option>
                                            <option value="5" data-val="4" <?php if(isset($product) && $product->product_vat_id == 6): ?> selected <?php endif; ?> >4%</option>
                                            <option value="7" data-val="0" <?php if(isset($product) && $product->product_vat_id == 7): ?> selected <?php endif; ?> >0%</option>
                                            <option value="8" data-val="0" <?php if(isset($product) && $product->product_vat_id == 8): ?> selected <?php endif; ?> >-</option>
                                        </select>
                                        <label for="product_vat_id">Κατηγορία ΦΠΑ</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col s12 m4">
                                    <div class="input-field">
                                        <i class="material-icons prefix">euro_symbol</i>
                                        <input type="text" id="price" name="price" <?php if(isset($product)): ?> value="<?php echo e($product->price); ?>" <?php endif; ?> required>
                                        <label for="price">Τιμή Λιανικής *</label>
                                    </div>
                                </div>
                                <div class="col s12 m4">
                                    <div class="input-field">
                                        <i class="material-icons prefix">loupe</i>
                                        <input type="text" id="vat_price" name="vat_price" <?php if(isset($product)): ?> value="<?php echo e($product->vat_price); ?>" <?php endif; ?> required>
                                        <label for="vat_price">Φ.Π.Α. *</label>
                                    </div>
                                </div>
                                <div class="col s12 m4">
                                    <div class="input-field">
                                        <i class="material-icons prefix">card_giftcard</i>
                                        <input type="text" id="discount_price" name="discount_price" <?php if(isset($product)): ?> value="<?php echo e($product->discount_price); ?>" <?php endif; ?>>
                                        <label for="discount_price">Ποσοστό Έκπτωσης</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col s12 m10">
                                    <div class="input-field">
                                        <i class="material-icons prefix">description</i>
                                        <textarea id="product_description" name="product_description" class="materialize-textarea"> <?php if(isset($product)): ?> <?php echo e($product->product_description); ?> <?php endif; ?> </textarea>
                                        <label for="product_description">Περιγραφή Προϊόντος</label>
                                    </div>
                                </div>
                                <div class="col s12 m2">
                                    <div class="input-field">
                                        <div class="switch">
                                            <label>
                                                Ανενεργό
                                                <input type="checkbox" name="active" <?php if(isset($product) && $product->active == 1): ?> checked <?php endif; ?>>
                                                <span class="lever"></span>
                                                Ενεργό
                                            </label>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="invoice-action-btn col s12 m4 right">
                                    <?php if(isset($product)): ?>
                                        <input type="submit" value="Ενημέρωση Προϊόντος" style="color: #fff;width: 100%;"
                                               class="btn display-flex align-items-center justify-content-center">
                                    <?php else: ?>
                                        <input type="submit" value="Καταχώρηση Νέου Προϊόντος" style="color: #fff;width: 100%;"
                                               class="btn display-flex align-items-center justify-content-center">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col xl3 m4 s12">
                    <h6 style="color: #fff;margin-top: -20px">Εικόνα Προϊόντος</h6>
                    <div class="input-field product-image">
                        <input type="file" name="image" data-max-file-size="3M" data-show-errors="true" data-allowed-file-extensions="png jpg JPG JPEG"
                               class="img-field dropify" <?php if( isset($product) && $product->product_image != NULL ): ?>  data-default-file="<?php echo e(url('images/products/'.$product->product_image)); ?>" <?php endif; ?>
                               value="" />
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    <script>
        $p = jQuery.noConflict();
        $p(document).ready(function(){
           $p('.dropify').dropify();

           $p('input#price').on('mouseout', function(){
              let price = $p(this).val();
              let vat = $p('select#product_vat_id option:selected').data('val');
              if(price > 0) {
                  //console.log(price, vat);
                  let vatValue = price * (vat / 100);
                  $p('label[for="vat_price"]').addClass('active');
                  $p('input#vat_price').val(custom_number_format(vatValue, 2, '.'));
                  console.log(vatValue)
              }
           });
        });

        function custom_number_format( number_input, decimals, dec_point, thousands_sep ) {
            var number       = ( number_input + '' ).replace( /[^0-9+\-Ee.]/g, '' );
            var finite_number   = !isFinite( +number ) ? 0 : +number;
            var finite_decimals = !isFinite( +decimals ) ? 0 : Math.abs( decimals );
            var seperater     = ( typeof thousands_sep === 'undefined' ) ? ',' : thousands_sep;
            var decimal_pont   = ( typeof dec_point === 'undefined' ) ? '.' : dec_point;
            var number_output   = '';
            var toFixedFix = function ( n, prec ) {
                if( ( '' + n ).indexOf( 'e' ) === -1 ) {
                    return +( Math.round( n + 'e+' + prec ) + 'e-' + prec );
                } else {
                    var arr = ( '' + n ).split( 'e' );
                    let sig = '';
                    if ( +arr[1] + prec > 0 ) {
                        sig = '+';
                    }
                    return ( +(Math.round( +arr[0] + 'e' + sig + ( +arr[1] + prec ) ) + 'e-' + prec ) ).toFixed( prec );
                }
            }
            number_output = ( finite_decimals ? toFixedFix( finite_number, finite_decimals ).toString() : '' + Math.round( finite_number ) ).split( '.' );
            if( number_output[0].length > 3 ) {
                number_output[0] = number_output[0].replace( /\B(?=(?:\d{3})+(?!\d))/g, seperater );
            }
            if( ( number_output[1] || '' ).length < finite_decimals ) {
                number_output[1] = number_output[1] || '';
                number_output[1] += new Array( finite_decimals - number_output[1].length + 1 ).join( '0' );
            }
            return number_output.join( decimal_pont );
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\mypointFrredom\resources\views/products/create.blade.php ENDPATH**/ ?>