<!-- BEGIN: Footer-->
<footer
  class="page-footer footer gradient-shadow footer-static footer-dark">
  <div class="footer-copyright">
    <div class="container">
      <span>&copy; myPoint App {{date('Y')}}  All rights reserved.
      </span>
      <span class="right hide-on-small-only">Developed by <a href="https://www.sphereweb.gr" target="_blank">Sphere Web Solutions</a>
      </span>
    </div>
  </div>
</footer>

<!-- END: Footer-->
